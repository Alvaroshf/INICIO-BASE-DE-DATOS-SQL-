
EJERCICIO GRUPAL 01

INTEGRANTES:

- Ricardo Cea 
- Simón Zelada
- Mauricio Morales
- Aracily Morales
- Álvaro Stuardo

Trabajo final en archivo Telovendo.sql